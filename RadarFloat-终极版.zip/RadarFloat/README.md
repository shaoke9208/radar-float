# 盯盘雷达悬浮球 App（GitHub Actions 自动编译版）

无需安装 Android Studio。把这个仓库整体上传 GitHub，Actions 会自动编译出 debug APK。

## 目录结构

```
RadarFloat/
├── .github/workflows/build.yml        # GitHub Actions 自动编译配置
├── .gitignore
├── settings.gradle
├── build.gradle                       # 根构建文件（声明 AGP 8.2.2）
├── gradle.properties
├── README.md
└── app/
    ├── build.gradle                   # app 模块构建文件（minSdk 24 / targetSdk 34）
    └── src/main/
        ├── AndroidManifest.xml        # 权限 + Activity/Service 声明
        ├── assets/
        │   └── radar.html             # ★ 把你的盯盘雷达 HTML 替换到这里
        ├── java/com/radar/float/
        │   ├── MainActivity.java      # 入口：授权引导 + 启动服务
        │   └── FloatService.java      # 悬浮球 + WebView + 前台保活
        └── res/
            ├── drawable/ic_launcher.xml       # 图标（Vector，无需图片文件）
            ├── layout/activity_main.xml       # 入口界面
            └── values/strings.xml / themes.xml
```

## 使用步骤

### 第一步：替换雷达页面
把你的盯盘雷达 HTML 单文件内容，**整体覆盖**到：
```
app/src/main/assets/radar.html
```
（当前是一个占位页，直接替换即可。JSONP 跨域和 localStorage 在 App 里都已放行。）

### 第二步：上传 GitHub
1. 在 GitHub 新建一个空仓库（Public 或 Private 都行）
2. 把 `RadarFloat/` 里面的**所有内容**（包括隐藏的 `.github` 文件夹）上传到仓库根目录
   - 注意：要传的是 RadarFloat **里面**的文件作为仓库根，而不是把 RadarFloat 文件夹套一层
3. 上传后 Actions 会自动开始编译（push 触发）

### 第三步：下载 APK
1. 打开仓库 → **Actions** 标签页 → 点最新的运行记录
2. 页面底部 **Artifacts** 区域 → 下载 `RadarFloat-debug-apk`
3. 解压得到 `app-debug.apk`，传到手机安装

> 也可以手动触发：Actions → Build APK → Run workflow

### 第四步：手机上使用
1. 安装并打开 App
2. 点「1. 授权悬浮窗权限」→ 在系统设置里允许"显示在其他应用上层"
3. 返回点「2. 启动悬浮球服务」
4. 切到同花顺 → 屏幕上有半透明小球
   - **点一下**：展开全屏盯盘页
   - **再点一下 / 点右上角 ✕ 收起**：收起，露出同花顺
   - **按住拖动**：移动小球位置
   - **长按 0.6 秒**：关闭悬浮球服务

## 技术说明

- minSdk 24 / targetSdk 34，悬浮窗用 `TYPE_APPLICATION_OVERLAY`
- 前台服务 `specialUse` 类型 + 常驻通知保活（targetSdk 34 已按新规范声明 FGS 类型）
- WebView 已开启：JavaScript、DOM Storage（localStorage）、allowFileAccess、混合内容（http 明文）
- Manifest 已加 `android:usesCleartextTraffic="true"`
- 零第三方依赖，编译只拉 Android 官方 SDK 和 Gradle，首次编译约 3~5 分钟
- 展开时 WebView 可聚焦（能弹键盘输入），收起时自动 onPause 省电
