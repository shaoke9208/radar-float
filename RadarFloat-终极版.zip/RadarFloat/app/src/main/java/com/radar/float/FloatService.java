package com.radar.float;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/**
 * 悬浮球前台服务：
 * - 半透明小球常驻（可拖动），点击展开/收起盯盘 WebView
 * - 长按 600ms 关闭服务
 * - 展开时全屏加载 assets/radar.html，收起后露出底下的同花顺
 */
public class FloatService extends Service {

    private static final int BALL_SIZE = 120;          /* 5xdp -> px 由 density 换算 */
    private static final long LONG_PRESS_MS = 600;
    private static final String ASSET_URL = "file:///android_asset/radar.html";

    /* 手机本地页面：存在则优先加载，替换文件后点"刷新"即生效 */
    private static final java.io.File LOCAL_FILE = new java.io.File(
            Environment.getExternalStorageDirectory(), "Radar/radar.html");

    private WindowManager wm;
    private int dp;                                    /* 密度换算系数 */
    private String currentUrl = ASSET_URL;             /* 当前加载的页面地址 */

    private FrameLayout ball;
    private WindowManager.LayoutParams ballParams;

    private LinearLayout panel;                        /* 展开后的全屏容器 */
    private WebView webView;
    private WindowManager.LayoutParams panelParams;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable longPressAction = this::stopSelfSafely;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        dp = getResources().getDisplayMetrics().density;
        startForegroundWithNotification();
        showBall();
    }

    /* ================= 前台通知保活 ================= */
    private void startForegroundWithNotification() {
        String channelId = "radar_float";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channelId,
                    getString(R.string.notify_channel),
                    NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder builder =
                (Build.VERSION.SDK_INT >= 26)
                        ? new Notification.Builder(this, channelId)
                        : new Notification.Builder(this);
        Notification notif = builder
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle(getString(R.string.notify_title))
                .setContentText(getString(R.string.notify_text))
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, notif);
        }
    }

    /* ================= 悬浮小球 ================= */
    private void showBall() {
        if (ball != null) return;
        ball = new FrameLayout(this);

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0x88111111);                       /* 半透明深色 */
        bg.setStroke((int) (2 * dp), 0xFFFF4444);      /* 红色描边 */
        ball.setBackground(bg);

        /* 球面上的红点，模拟雷达 */
        View dot = new View(this);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(0xFFFF4444);
        dot.setBackground(dotBg);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(
                (int) (12 * dp), (int) (12 * dp), Gravity.CENTER);
        dot.setLayoutParams(dlp);
        ball.addView(dot);

        ballParams = new WindowManager.LayoutParams(
                (int) (56 * dp), (int) (56 * dp),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        ballParams.gravity = Gravity.TOP | Gravity.START;
        ballParams.x = 20;
        ballParams.y = 300;

        ball.setOnTouchListener(ballTouchListener);
        wm.addView(ball, ballParams);
    }

    private void removeBall() {
        if (ball != null) {
            try { wm.removeView(ball); } catch (Exception ignored) {}
            ball = null;
        }
    }

    /* 拖动 + 点击 + 长按手势区分 */
    private final View.OnTouchListener ballTouchListener = new View.OnTouchListener() {
        float downRawX, downRawY;
        int startX, startY;
        boolean moved;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX = e.getRawX();
                    downRawY = e.getRawY();
                    startX = ballParams.x;
                    startY = ballParams.y;
                    moved = false;
                    handler.postDelayed(longPressAction, LONG_PRESS_MS);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - downRawX;
                    float dy = e.getRawY() - downRawY;
                    if (!moved && (Math.abs(dx) > 10 * dp || Math.abs(dy) > 10 * dp)) {
                        moved = true;
                        handler.removeCallbacks(longPressAction);
                    }
                    if (moved) {
                        ballParams.x = startX + (int) dx;
                        ballParams.y = startY + (int) dy;
                        try { wm.updateViewLayout(ball, ballParams); } catch (Exception ignored) {}
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(longPressAction);
                    if (!moved) toggle();              /* 原地点击：展开/收起 */
                    return true;
            }
            return false;
        }
    };

    private void stopSelfSafely() {
        stopSelf();
    }

    /* ================= 展开 / 收起 ================= */
    private void toggle() {
        if (panel == null) expand(); else collapse();
    }

    private void expand() {
        currentUrl = pickUrl();    /* 每次展开重新检测手机本地页面 */
        removeBall();

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xFF0A0A0A);

        /* 顶部条：刷新 + 收起按钮 */
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(0xFF1A1A1A);
        topBar.setPadding((int) (12 * dp), (int) (6 * dp), (int) (12 * dp), (int) (6 * dp));

        Button btnRefresh = new Button(this);
        btnRefresh.setText("⟳ 刷新");
        btnRefresh.setTextSize(14);
        btnRefresh.setAllCaps(false);
        btnRefresh.setOnClickListener(v -> reloadRadar());
        topBar.addView(btnRefresh);

        Button btnClose = new Button(this);
        btnClose.setText("✕ 收起");
        btnClose.setTextSize(14);
        btnClose.setAllCaps(false);
        btnClose.setOnClickListener(v -> collapse());
        topBar.addView(btnClose);

        panel.addView(topBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        /* WebView：JS + DOM Storage + 明文流量 */
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);                 /* localStorage 可用 */
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= 21) {
            ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW); /* 允许 http */
        }
        webView.setWebChromeClient(new WebChromeClient());
        webView.setBackgroundColor(Color.parseColor("#0A0A0A"));
        webView.loadUrl(currentUrl);

        panel.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT, 1f));

        panelParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN   /* 可聚焦：WebView 能弹键盘输入 */
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, /* 展开时屏幕常亮 */
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.CENTER;

        wm.addView(panel, panelParams);
    }

    private void collapse() {
        if (panel != null) {
            /* 先暂停 WebView 活动再移除，释放渲染资源让同花顺保持流畅 */
            if (webView != null) {
                webView.onPause();
                webView.pauseTimers();
            }
            try { wm.removeView(panel); } catch (Exception ignored) {}
            panel = null;
            webView = null;
        }
        showBall();
    }

    /* ================= 页面来源：手机本地优先，内置兜底 ================= */
    private static String pickUrl() {
        return (LOCAL_FILE.exists() && LOCAL_FILE.length() > 0 && LOCAL_FILE.canRead())
                ? "file://" + LOCAL_FILE.getAbsolutePath()
                : ASSET_URL;
    }

    /* 顶栏"刷新"：重新检测手机里的 radar.html 并热加载，替换文件后立即生效 */
    private void reloadRadar() {
        if (webView == null) return;
        currentUrl = pickUrl();
        webView.loadUrl(currentUrl);
        android.widget.Toast.makeText(this,
                currentUrl.equals(ASSET_URL)
                        ? "未找到手机页面，已加载内置版"
                        : "已刷新：" + LOCAL_FILE.getAbsolutePath(),
                android.widget.Toast.LENGTH_SHORT).show();
    }

    /* ================= 生命周期 ================= */
    @Override
    public void onDestroy() {
        handler.removeCallbacks(longPressAction);
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        removeBall();
        if (panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
        super.onDestroy();
    }
}
