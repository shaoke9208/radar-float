package com.radar.float;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int REQ_NOTIFICATIONS = 100;

    /* 手机本地雷达目录：/sdcard/Radar/radar.html 优先于内置页面 */
    public static final File RADAR_DIR = new File(
            Environment.getExternalStorageDirectory(), "Radar");
    public static final File RADAR_FILE = new File(RADAR_DIR, "radar.html");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnPermission = findViewById(R.id.btnPermission);
        Button btnStorage = findViewById(R.id.btnStorage);
        Button btnStart = findViewById(R.id.btnStart);

        /* 1. 悬浮窗权限 */
        btnPermission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } else {
                Toast.makeText(this, "悬浮窗权限已授予", Toast.LENGTH_SHORT).show();
            }
        });

        /* 2. 所有文件访问权限（MANAGE_EXTERNAL_STORAGE，Android 11+ 跳系统设置） */
        btnStorage.setOnClickListener(v -> requestStorageAccess());

        /* 3. 启动悬浮球 */
        btnStart.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先授权悬浮窗权限", Toast.LENGTH_SHORT).show();
                return;
            }
            /* 启动前先确保电池优化豁免（防华为/小米等杀后台），未豁免则跳转授权 */
            if (!isIgnoringBattery()) {
                requestIgnoreBattery();
                return;
            }
            /* 有文件权限就先确保 /sdcard/Radar/radar.html 就绪 */
            if (hasStorageAccess()) ensureRadarFolder();
            Intent it = new Intent(this, FloatService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(it);
            else startService(it);
            Toast.makeText(this, "悬浮球已启动，切到同花顺试试", Toast.LENGTH_SHORT).show();
            finish();
        });

        /* Android 13+ 通知权限（可选，不授权也能运行） */
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    REQ_NOTIFICATIONS);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        /* 从系统设置授权页返回时，自动建目录并复制初版页面 */
        if (hasStorageAccess()) ensureRadarFolder();
    }

    /* ================= 电池优化豁免：防国产ROM杀后台 ================= */
    private boolean isIgnoringBattery() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private void requestIgnoreBattery() {
        try {
            /* 弹出系统对话框"允许应用在后台运行？"，点允许即豁免 */
            startActivity(new Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
            Toast.makeText(this, "请选择\"允许\"，防止悬浮球被系统杀掉", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            /* 个别ROM不支持该Action，退回电池优化列表页手动查找 */
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
                Toast.makeText(this, "请手动到 设置-电池 中关闭本应用的优化", Toast.LENGTH_LONG).show();
            }
        }
    }

    private boolean hasStorageAccess() {
        return Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager();
    }

    private void requestStorageAccess() {
        if (hasStorageAccess()) {
            ensureRadarFolder();
            Toast.makeText(this, "文件权限已就绪：" + RADAR_FILE.getAbsolutePath(),
                    Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Intent it = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(it);
        } catch (Exception e) {
            /* 部分ROM没有直达页，退回通用列表页 */
            startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
        }
    }

    /**
     * 首次运行时：创建 /sdcard/Radar/ 并把内置 assets/radar.html 复制过去一份，
     * 之后用户直接覆盖该文件即可更新界面，无需重新编译 APK。
     * 已存在则不覆盖（保留用户手机上的最新版本）。
     */
    private void ensureRadarFolder() {
        try {
            if (!RADAR_DIR.exists()) RADAR_DIR.mkdirs();
            if (RADAR_FILE.exists()) return;   /* 不覆盖手机上已有的版本 */
            InputStream in = getAssets().open("radar.html");
            OutputStream out = new FileOutputStream(RADAR_FILE);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.flush();
            out.close();
            in.close();
            Toast.makeText(this, "已复制初版页面到 " + RADAR_FILE.getAbsolutePath(),
                    Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(this, "复制失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
